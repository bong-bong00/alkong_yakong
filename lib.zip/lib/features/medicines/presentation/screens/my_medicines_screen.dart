import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tabler_icons/flutter_tabler_icons.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/constants/app_colors.dart';
import '../../../../core/theme/medicine_preserved_typography.dart';
import '../../../../core/widgets/recovery_view.dart';
import '../../../../core/widgets/senior_button.dart';
import '../../../../core/widgets/senior_card.dart';
import '../../../../core/widgets/senior_header.dart';
import '../../application/user_medicines_controller.dart';
import '../../domain/display_policy.dart';
import '../../domain/user_medicine_models.dart';

/// 내 약 — 활성 약 종류당 1행 (서버 `/medicines`).
///
/// 시안 38. 맨 위에 "처방전 등록"과 "AI 약사 상담"을 큰 두 칸으로 두고,
/// 그 아래 지금 드시는 약을 쌓는다. 오늘 홈에서 내린 두 길이 여기 모인다.
///
/// **뒤로 가는 머리띠는 두지 않는다.** 이 화면은 아래 탭에서 바로 열리는
/// 자리라 돌아갈 곳이 없고, 탭이 있는데 뒤로 화살표까지 있으면 어느 쪽이
/// 돌아가는 길인지 헷갈린다.
class MyMedicinesScreen extends ConsumerWidget {
  /// 남아 있는 깃발. 간편 화면 쉘이 자기 걸음 머리를 따로 그린다.
  final bool asTab;

  const MyMedicinesScreen({super.key, this.asTab = true});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final medicines = ref.watch(userMedicinesProvider);

    return Scaffold(
      backgroundColor: AppColors.pageBg,
      // 탭으로 열면 머리띠가 없다. 제목이 상태바에 붙지 않게 여기서 피한다.
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Expanded(
              child: medicines.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (error, _) => RecoveryView(
                  title: '약 목록을\n불러오지 못했어요',
                  reassurance: '인터넷이나 서버가 잠깐 끊겼을 수 있어요. ',
                  reassuranceEmphasis: '고장이 아니니 걱정하지 마세요.',
                  steps: const ['잠시 후 다시 눌러 보세요', '와이파이나 데이터 연결을 확인해 보세요'],
                  actionLabel: '다시 불러오기',
                  onAction: () =>
                      ref.read(userMedicinesProvider.notifier).refresh(),
                  stillWorksTitle: '지금도 할 수 있는 것',
                  stillWorksBody: '오늘 홈에서 복약 기록과 처방전 사진 찍기는 그대로 쓸 수 있어요.',
                ),
                data: (items) => _MedicineList(items: items, asTab: asTab),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MedicineList extends StatelessWidget {
  final List<UserMedicine> items;
  final bool asTab;

  const _MedicineList({required this.items, this.asTab = false});

  /// 시안 38 — 제목 아래 큰 두 칸. 처방전 넣기는 파란 면으로 두어
  /// 이 화면에서 가장 먼저 눈에 들어오게 한다.
  Widget _actions(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: _ActionTile(
              icon: TablerIcons.camera,
              label: '처방전 등록',
              filled: true,
              onTap: () => context.push('/prescription'),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: _ActionTile(
              // 시안은 동그라미 안에 물음표를 둔다. 말풍선은 "대화"를
              // 말하지만 여기서 하는 일은 "묻는" 것이다.
              icon: TablerIcons.help_circle,
              label: 'AI 약사 상담',
              onTap: () => context.push('/drug-explain'),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 28),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SeniorCard(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  const Icon(
                    TablerIcons.pill,
                    size: 42,
                    color: AppColors.point,
                  ),
                  const SizedBox(height: 14),
                  Text('등록된 약이 없어요', style: AppText.cardTitle(size: 22)),
                  const SizedBox(height: 8),
                  Text(
                    '처방전 사진을 찍으면 약을 확인한 뒤 등록할 수 있어요.',
                    textAlign: TextAlign.center,
                    style: AppText.body(color: AppColors.textSecondary),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SeniorButton(
              label: '처방전 등록하기',
              onPressed: () => context.push('/prescription'),
            ),
          ],
        ),
      );
    }

    final active = items.where((item) => item.status == 'active').toList();
    final past = items.where((item) => item.status != 'active').toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 28),
      children: [
        if (asTab) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
            child: Text('내 약', style: AppText.screenTitle(size: 28)),
          ),
          const SizedBox(height: 14),
        ],
        _actions(context),
        // 머리말을 두지 않는다. 약 줄이 바로 보이면 무엇을 누를지
        // 더 설명할 것이 없다.
        const SizedBox(height: 18),
        _GroupedMedicines(medicines: active),
        // 지금 안 드시는 약은 줄 하나로 접어 둔다. 목록을 보는 이유는
        // 대부분 "지금 먹는 약"이기 때문이다.
        if (past.isNotEmpty) ...[
          const SizedBox(height: 2),
          _PastMedicines(medicines: past),
        ],
      ],
    );
  }
}

/// 내 약 맨 위의 큰 두 칸.
class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String label;

  /// 파란 면으로 채울지. 이 화면에서 하나만 채운다.
  final bool filled;
  final VoidCallback onTap;

  const _ActionTile({
    required this.icon,
    required this.label,
    this.filled = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final ink = filled ? Colors.white : AppColors.textPrimary;
    return Semantics(
      button: true,
      label: label,
      child: GestureDetector(
        onTap: onTap,
        child: ExcludeSemantics(
          child: Container(
            constraints: const BoxConstraints(minHeight: 112),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: filled ? AppColors.pointFill : AppColors.surface,
              borderRadius: BorderRadius.circular(26),
              boxShadow: filled ? kAccentShadow : kCardShadow,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: filled ? AppColors.surface : AppColors.pointTint,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, size: 26, color: AppColors.point),
                ),
                const SizedBox(height: 12),
                Text(label, style: AppText.cardTitle(size: 20, color: ink)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _GroupedMedicines extends StatelessWidget {
  final List<UserMedicine> medicines;

  const _GroupedMedicines({required this.medicines});

  @override
  Widget build(BuildContext context) {
    // Confirmed pair warnings apply to both members, not just the row carrying
    // the warning. Do not infer conflicts from check_needed/unknown results.
    String nameKey(String name) =>
        name.split('(').first.replaceAll(RegExp(r'\s+'), '').trim();
    final conflictNames = <String>{
      for (final medicine in medicines)
        if (medicine.interactionStatus == 'risk_found') ...[
          nameKey(medicine.displayName),
          ...medicine.interactionConflictNames.map(nameKey),
        ],
    }..remove('');
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (final type in MedicineUseType.values)
          if (medicines.any((medicine) => medicine.useType == type)) ...[
            // 묶음 이름은 박스로 두르지 않는다 — 박스는 약에만 쓴다.
            Padding(
              padding: const EdgeInsets.fromLTRB(4, 2, 4, 10),
              child: Row(
                children: [
                  Icon(
                    switch (type) {
                      MedicineUseType.eat => TablerIcons.pill,
                      MedicineUseType.apply => Icons.back_hand_outlined,
                      MedicineUseType.patch => Icons.healing_outlined,
                      MedicineUseType.eye => Icons.visibility_outlined,
                      MedicineUseType.unknown => Icons.help_outline,
                      _ => Icons.medical_services_outlined,
                    },
                    color: AppColors.point,
                    size: 23,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(type.label, style: AppText.label(size: 19)),
                  ),
                  Text(
                    '${medicines.where((medicine) => medicine.useType == type).length}가지',
                    style: AppText.body(
                      size: 17,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
            for (final medicine in medicines.where(
              (medicine) => medicine.useType == type,
            )) ...[
              _MedicineCard(
                medicine: medicine,
                pairConflict: conflictNames.contains(
                  nameKey(medicine.displayName),
                ),
              ),
              const SizedBox(height: 12),
            ],
          ],
      ],
    );
  }
}

class _MedicineCard extends StatelessWidget {
  final UserMedicine medicine;
  final bool pairConflict;

  const _MedicineCard({required this.medicine, this.pairConflict = false});

  @override
  Widget build(BuildContext context) {
    final hasConflict =
        pairConflict || medicine.interactionStatus == 'risk_found';
    return SeniorCard(
      radius: 26,
      borderColor: hasConflict ? AppColors.danger : null,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      onTap: () => context.push('/medicines/${medicine.medicineCode}'),
      child: Row(
        children: [
          // 홈 카드와 같은 생김새여야 같은 약으로 읽힌다.
          PillPhoto(size: 56, imageUrl: medicine.imageUrl),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nameWithoutStrength(
                    medicine.displayName,
                    strength: medicine.ingredientStrength,
                  ),
                  style: AppText.cardTitle(size: 21),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (hasConflict) ...[
                  const SizedBox(height: 4),
                  Text(
                    '[충돌]',
                    style: AppText.label(size: 18, color: AppColors.danger),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 10),
          // 누를 수 있다는 것을 동그란 자리로 알린다.
          Container(
            width: 40,
            height: 40,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              color: AppColors.pointTint,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              TablerIcons.chevron_right,
              size: 22,
              color: AppColors.point,
            ),
          ),
        ],
      ),
    );
  }
}

/// 지금은 안 드시는 약. 줄을 누르면 그 자리에서 펴진다.
class _PastMedicines extends StatefulWidget {
  final List<UserMedicine> medicines;

  const _PastMedicines({required this.medicines});

  @override
  State<_PastMedicines> createState() => _PastMedicinesState();
}

class _PastMedicinesState extends State<_PastMedicines> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    // 칸 하나로 둔다. 접혀 있을 때는 "이전에 사용한 약" 한 줄만 보이고,
    // 누르면 그 칸이 아래로 늘어나며 약들이 따라 나온다. 칸을 둘로 나누면
    // 펼친 목록이 남의 칸처럼 떨어져 보인다.
    return _StackedCard(
      child: SeniorCard(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SeniorListRow(
              label: '이전에 사용한 약',
              labelColor: AppColors.textTertiary,
              value: '${widget.medicines.length}가지',
              trailing: const SeniorChevron(),
              onTap: () => setState(() => _open = !_open),
            ),
            if (_open)
              for (final medicine in widget.medicines) ...[
                // 제목 줄과 약 줄을 가는 선으로 가른다.
                const SeniorDivider(),
                SeniorListRow(
                  label: nameWithoutStrength(
                    medicine.displayName,
                    strength: medicine.ingredientStrength,
                  ),
                  labelColor: AppColors.textTertiary,
                  value: medicine.useType.label,
                  trailing: const SeniorChevron(),
                  onTap: () =>
                      context.push('/medicines/${medicine.medicineCode}'),
                ),
              ],
          ],
        ),
      ),
    );
  }
}

/// 카드 한 장이 뒤에 더 깔린 모양.
///
/// 지금 드시는 약과 같은 흰 카드를 쓰되, 뒤에 회색 카드가 왼쪽으로 조금
/// 삐져나오게 둔다. "이 아래에 지난 약이 더 있다"를 색이 아니라 모양으로 말한다.
class _StackedCard extends StatelessWidget {
  final Widget child;

  const _StackedCard({required this.child});

  /// 뒤 카드가 왼쪽으로 보이는 만큼.
  static const double _peek = 6;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // 카드와 똑같은 크기·모서리로 한 장을 왼쪽으로 밀어 깐다.
        // 그래야 삐져나온 회색이 위아래 모서리까지 카드를 따라 휘어진다.
        Positioned(
          left: 0,
          right: _peek,
          top: 0,
          bottom: 0,
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: AppColors.chevron,
              borderRadius: BorderRadius.circular(22),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(left: _peek),
          child: child,
        ),
      ],
    );
  }
}

/// 복용 시간대를 "아침 · 저녁" 한 줄로 만든다.
///
/// 서버가 한글로도 영문으로도 보낼 수 있어 둘 다 받는다.
/// 알 수 없는 값만 들어 있으면 null — **배지를 만들지 않는다.**
String? slotBadgeFor(List<String> times) {
  const order = ['아침', '점심', '저녁', '자기 전'];
  const alias = {
    'morning': '아침',
    'lunch': '점심',
    'noon': '점심',
    'afternoon': '점심',
    'evening': '저녁',
    'dinner': '저녁',
    'night': '자기 전',
    'bedtime': '자기 전',
  };

  final found = <String>{};
  for (final raw in times) {
    final text = raw.trim();
    if (text.isEmpty) continue;
    final lower = text.toLowerCase();
    for (final entry in alias.entries) {
      if (lower.contains(entry.key)) found.add(entry.value);
    }
    for (final label in order) {
      if (text.contains(label)) found.add(label);
    }
  }
  if (found.isEmpty) return null;
  return order.where(found.contains).join(' · ');
}
